﻿using System.Windows;

namespace CookBook.RecipeManager.GUI.Windows
{
    public partial class App : Application
    {

        public App()
        {
            InitializeComponent();
        }
    }
}